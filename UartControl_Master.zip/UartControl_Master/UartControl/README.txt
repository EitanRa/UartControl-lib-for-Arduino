UartControl by Eitan Rabinovitch

Save this folder in: Arduino\libraries

Commands:
begin - Start simulating
click - Mouse-left-button click
rightClick - Mouse-right-button click
leftDown - Mouse-left-button down
leftUp - Mouse-left-button up
rightDown - Mouse-right-button down
rightUp - Mouse-right-button up
middleDown - Mouse-middle-button down
middleUp - Mouse-middle-button up
moveCursor(int xsteps, int ysteps) - Move the cursor x and y steps
getCursorX - Get cursor's x value[-1 = Error]
getCursorY - Get Cursor's y value[-1 = Error]
keyPress(String key) - Key press[List of special keys here: https://katzr.net/8ffd28]

http://www.eitanra.022.co.il/BRPortal/br/P100.jsp